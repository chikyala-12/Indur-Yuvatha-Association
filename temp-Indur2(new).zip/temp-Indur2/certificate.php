<!DOCTYPE html>
<html lang="en">
    <head>
<title>Certificates</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">

<style>
    .button{
        position: relative;
        left:90%;
        top:20px;
        width:55px;
        height:30px;
    }
</style>
</head>
<body>

<div class="w3-container w3-grey" style="position:relative">
 <a class="w3-btn  w3-xlarge w3-right " style="position:absolute;top:126px;right:42px;"><a href="service.html"><button  class="button">Back</button></a></a>
 <h1 class="w3-jumbo w3-text-grey" style="text-shadow:1px 1px 0 #444">Certificates & Awards</h1>
 
</div>

<div class="w3-grey w3-animate-zoom" style="padding:20px 50px;background-image:url('pic_boat_portrait.jpg');
background-size:cover;">

<div class="w3-section w3-row-padding">

  <div class="w3-twothird">
    <div class="w3-card-4">
      <div class="w3-display-container">
        <img src="img/C2.jpg" alt="Car" style="width:100%">
        <div class="w3-display-bottomleft w3-container w3-xlarge w3-text-black"></div>
      </div>
      <div class="w3-container w3-light-grey">
        <p>Swachh Bharat  Camp state level second price </p>
        
      </div>
    </div>
  </div>
  <div class="w3-third w3-container w3-center">
    <div class="w3-card-4 w3-section" >
      <div class="w3-container w3-white" >
      <p class="w3-jumbo"><img src="img/C3.jpg"  width="300px" height="350px"></p>
      
      </div>
      <div class="w3-container " >
      <p>Presented by DG Dilwar singh</p>
      </div>
    </div>
    <div class="w3-card-4 w3-section">
      <div class="w3-container w3-white">
      <p class="w3-xxlarge"><img src="img/C4.jpg" width="300px" height="350px"></p>
      
      </div>
      <div class="w3-container">
      <p>Presented by DG Dilwar singh</p>
      </div>
    </div>
    <div class="w3-card-4 w3-section">
        <div class="w3-container w3-white">
        <p class="w3-xxlarge"><img src="img/C5.jpg" width="300px" height="350px"></p>
        
        </div>
        <div class="w3-container">
        <p>Presented by telangana state</p>
        </div>
      </div>
  </div>
</div>

<div class="w3-section w3-container">
<div class="w3-card-4">
  <div class="w3-container w3-padding-16 w3-black w3-xxlarge">
    <p>«<i> Make it as simple as possible, but not simpler </i>»</p>
  </div>
  
  </div>
</div>
</div>

</div>



</body>
</html>
