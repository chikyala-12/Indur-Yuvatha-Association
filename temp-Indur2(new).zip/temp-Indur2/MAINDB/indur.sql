-- phpMyAdmin SQL Dump
-- version 5.1.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 15, 2022 at 11:30 AM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 7.4.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `indur`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `Username` varchar(100) NOT NULL,
  `Password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`Username`, `Password`) VALUES
('admin', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `donation`
--

CREATE TABLE `donation` (
  `s_no` int(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `contact` varchar(100) NOT NULL,
  `address` varchar(100) NOT NULL,
  `item` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `donation`
--

INSERT INTO `donation` (`s_no`, `name`, `contact`, `address`, `item`) VALUES
(12, 'VAMSHI', '9900889977', 'Jeedimetla, Hyderabad', 'Food'),
(14, 'SANDEEP', '9948039493', 'Jeedimetla, Hyderabad', 'Both');

-- --------------------------------------------------------

--
-- Table structure for table `donationpay`
--

CREATE TABLE `donationpay` (
  `sno` int(11) NOT NULL,
  `fullname` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `address` varchar(100) NOT NULL,
  `contact` varchar(100) NOT NULL,
  `state` varchar(100) NOT NULL,
  `zip` varchar(100) NOT NULL,
  `amount` varchar(100) NOT NULL,
  `cardname` varchar(100) NOT NULL,
  `cardnumber` varchar(100) NOT NULL,
  `expmonth` varchar(100) NOT NULL,
  `expyear` varchar(100) NOT NULL,
  `cvv` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `donationpay`
--

INSERT INTO `donationpay` (`sno`, `fullname`, `email`, `address`, `contact`, `state`, `zip`, `amount`, `cardname`, `cardnumber`, `expmonth`, `expyear`, `cvv`) VALUES
(2, 'SRIKANTH', 'sanket@gmail.com', 'Hyderabad', '9900889900', 'Telangana', '507123', '20000', 'Sandeep', '112211122112', 'Feb', '2022', '123'),
(3, '', '', '', '', '', '', '', '', '', '', '', ''),
(4, '', '', '', '', '', '', '', '', '', '', '', ''),
(5, '', '', '', '', '', '', '', '', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `donationupload`
--

CREATE TABLE `donationupload` (
  `s_no` int(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `contact` varchar(100) NOT NULL,
  `location` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `donationupload`
--

INSERT INTO `donationupload` (`s_no`, `name`, `contact`, `location`) VALUES
(1, 'PRUDVI', '9948039493', '4.jpg'),
(5, 'Kiran', '1299900099', '5.jpg'),
(6, 'Pranav', '8899889988', '1.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `joinus`
--

CREATE TABLE `joinus` (
  `id` int(100) NOT NULL,
  `firstname` varchar(150) NOT NULL,
  `lastname` varchar(100) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `joinus`
--

INSERT INTO `joinus` (`id`, `firstname`, `lastname`, `email`, `password`) VALUES
(1, '0', '0', '0', '1234'),
(2, '0', '0', '0', '4567'),
(3, 'SAND', '2', 'sunil@gmail.com', '1234'),
(4, '', '', 'sunil', '1234'),
(5, 'vamshi', 'krishna', 'charil', '1234'),
(6, 'vamshi', 'krishna', 'dhonivamshi7@gmail.com', '1234'),
(7, 'chari', 'krishna', 'ipsvamshi100@gmail.com', '1234'),
(8, 'vamshi', 'krishna', 'dhonivamshi7@gmail', '1234'),
(9, 'vamshi', 'vamshi', 'dhonivamshi7@gmail.com', '1234');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `donation`
--
ALTER TABLE `donation`
  ADD PRIMARY KEY (`s_no`);

--
-- Indexes for table `donationpay`
--
ALTER TABLE `donationpay`
  ADD PRIMARY KEY (`sno`);

--
-- Indexes for table `donationupload`
--
ALTER TABLE `donationupload`
  ADD PRIMARY KEY (`s_no`);

--
-- Indexes for table `joinus`
--
ALTER TABLE `joinus`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `donation`
--
ALTER TABLE `donation`
  MODIFY `s_no` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `donationpay`
--
ALTER TABLE `donationpay`
  MODIFY `sno` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `donationupload`
--
ALTER TABLE `donationupload`
  MODIFY `s_no` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `joinus`
--
ALTER TABLE `joinus`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
