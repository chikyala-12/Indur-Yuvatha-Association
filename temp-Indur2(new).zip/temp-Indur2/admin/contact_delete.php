<?php 

include('db.php');

$get_id=$_GET['s_no'];

mysqli_query($conn,"delete from contact where s_no = '$get_id' ")or die(mysqli_error($conn));
header('location:dashboard.php');
?>