
<?php 
include('includes/sidebar.php');

?>
      <section id="main-content">
          <section class="wrapper">
          	<h3><i class="fa fa-angle-right"></i></h3>
				<div class="row">

<?php include('db.php'); ?>
<?php include('header.php'); ?>
<body>
    <div class="row-fluid">
        <div class="span12">
            <div class="container">
<h3><b>WELCOME TO ADMIN DASHBOARD</b></h3>
        
        </div>
        </div>
        </div>
    </div>
		</section>
      </section
  ></section>
    <script src="assets/js/jquery.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
    <script class="include" type="text/javascript" src="assets/js/jquery.dcjqaccordion.2.7.js"></script>
    <script src="assets/js/jquery.scrollTo.min.js"></script>
    <script src="assets/js/jquery.nicescroll.js" type="text/javascript"></script>
    <script src="assets/js/common-scripts.js"></script>

  </body>
</html>
