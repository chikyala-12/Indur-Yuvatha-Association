<?php 

include('db.php');

$get_id=$_GET['s_no'];

mysqli_query($con,"delete from donationupload where s_no = '$get_id' ")or die(mysqli_error($con));
header('location:events_dash.php');
?>