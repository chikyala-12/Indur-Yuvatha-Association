<?php
	include('db.php');
						$status= $_POST['status'];
						$id=$_POST['id'];
						mysqli_query($conn,"update complaints set status='$status' where s_no='$id'")
						or die(mysqli_error($conn));
									
										header('location:complaint_dash.php');
?>								