<?php
	include('db.php');
							
							if (!isset($_FILES['image']['tmp_name'])) {
							echo "";
							}else{
							$file=$_FILES['image']['tmp_name'];
							$image = $_FILES["image"] ["name"];
							$image_name= addslashes($_FILES['image']['name']);
							$size = $_FILES["image"] ["size"];
							$error = $_FILES["image"] ["error"];

							if ($error > 0){
										die("Error uploading file! Code $error.");
									}
										
									else
										{

									move_uploaded_file($_FILES["image"]["tmp_name"],"upload/" . $_FILES["image"]["name"]);			
									$location=$_FILES["image"]["name"];
									$fname= $_POST['fname'];
									$contact= $_POST['contact'];
									

						mysqli_query($con,"insert into donationupload (name,contact,location) 
						values('$fname','$contact','$location')")or die(mysqli_error($con));
									
									}
										header('location:events_dash.php');
									
							}
?>								