<?php 

include('db.php');

$get_id=$_GET['s_no'];

mysqli_query($con,"delete from donation where s_no = '$get_id' ")or die(mysqli_error($conn));
header('location:viewdonations.php');
?>