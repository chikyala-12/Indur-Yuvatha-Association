
<?php 
include('includes/sidebar.php');
?>

      <section id="main-content">
          <section class="wrapper">
          	<h3><i class="fa fa-angle-right"></i>Upload Donations Details</h3>
							<div class="row">
<?php include('db.php'); ?>
<?php include('header.php'); ?>
<body>


    <div class="row-fluid">
        <div class="span12">


         

            <div class="container">



                    
<?php include('event_modal.php'); ?>

                        <table cellpadding="0" cellspacing="0" border="0" class="table table-striped table-bordered" id="example">
                            <div class="alert alert-info">
                                <button type="button" class="close" data-dismiss="alert">&times;</button>
                                <strong><i class="icon-user icon-large"></i>&nbsp;Data Table</strong>
                            </div>
                            <thead>
                                <tr>
                                    <th style="text-align:center;" >SNO</th>
                                    <th style="text-align:center;">Name</th>
									<th style="text-align:center;">Contact</th>
                                    <th style="text-align:center;">Image</th>                                 
									<th style="text-align:center;">Action</th>
                                </tr>
                            </thead>
                            <tbody>
								<?php
								
								$result= mysqli_query($con,"select * from donationupload order by s_no DESC" ) or die (mysqli_error($con));
								while ($row= mysqli_fetch_array ($result) ){
								$id=$row['s_no'];
								?>
								<tr>
								
                                                               <td style="text-align:center; word-break:break-all; width:300px;"> <?php echo $row ['s_no']; ?></td>
                                                                 <td style="text-align:center; word-break:break-all; width:300px;"> <?php echo $row ['name']; ?></td>
																 <td style="text-align:center; word-break:break-all; width:300px;"> <?php echo $row ['contact']; ?></td>

                                                               <td style="text-align:center; margin-top:10px; word-break:break-all; width:450px; line-height:100px;"><a href="#<?php  echo $id;?>" data-toggle="modal">
									<?php if($row['location'] != ""): ?>
									<img src="upload/<?php echo $row['location']; ?>" width="100px" height="100px" style="border:1px solid #333333;">
									<?php else: ?>
<!--									<img src="images/default.png" width="100px" height="100px" style="border:1px solid #333333;">-->
									<?php endif; ?>
									</a>
                                                                </td>
								<td style="text-align:center; width:350px;">
<!--									<a href="edit.php<?php echo '?id='.$id; ?>" class="btn btn-info">Edit</a>-->
									 <a href="#delete<?php echo $id;?>"  data-toggle="modal"  class="btn btn-danger" >Delete </a>
								</td>	
										<!-- Modal -->
								<div id="delete<?php  echo $id;?>" class="modal hide fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
								<div class="modal-header">
								<h3 id="myModalLabel">Delete</h3>
								</div>
								<div class="modal-body">
								<p><div class="alert alert-danger">Are you Sure you want Delete?</p>
								</div>
								<hr>
								<div class="modal-footer">
								<button class="btn btn-inverse" data-dismiss="modal" aria-hidden="true">No</button>
								<a href="event_delete.php<?php echo '?s_no='.$id; ?>" class="btn btn-danger">Yes</a>
								</div>
								</div>
								</div>
								</tr>

								<!-- Modal Bigger Image -->
								

								<?php } ?>  
                            </tbody>
                        </table>


          
        </div>
        </div>
        </div>
    </div>
		</section>
      </section
  ></section>
    <script src="assets/js/jquery.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
    <script class="include" type="text/javascript" src="assets/js/jquery.dcjqaccordion.2.7.js"></script>
    <script src="assets/js/jquery.scrollTo.min.js"></script>
    <script src="assets/js/jquery.nicescroll.js" type="text/javascript"></script>
    <script src="assets/js/common-scripts.js"></script>
  <script>
      $(function(){
          $('select.styled').customSelect();
      });

  </script>

  </body>
</html>
<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

