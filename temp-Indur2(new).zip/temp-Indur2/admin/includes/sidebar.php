<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="Dashboard">
    <meta name="keyword" content="Dashboard, Bootstrap, Admin, Template, Theme, Responsive, Fluid, Retina">

    <title>Admin</title>
    <!--    <link href="assets/css/bootstrap.css" rel="stylesheet">-->
    <link href="assets/font-awesome/css/font-awesome.css" rel="stylesheet" />
    <link href="assets/css/style.css" rel="stylesheet">
    <link href="assets/css/style-responsive.css" rel="stylesheet">
</head>

<body>

    <section id="container">
        <header class="header black-bg" style="background-color:#ADD8E6">
            <div class="sidebar-toggle-box">
                <div class="fa fa-bars tooltips" data-placement="right" data-original-title="Toggle Navigation"></div>
            </div>
            <a href="#" class="logo"><b>ADMIN - INDUR YOUTH ASSOCIATION</b><b></b></a>
            <div class="nav notify-row" id="top_menu">

                </ul>
            </div>
            <div class="top-menu">
                <ul class="nav pull-right top-menu">
                    <li><a class="logout" href="logout.php">Logout</a></li>
                </ul>
            </div>
        </header>
        <aside>
            <div id="sidebar" class="nav-collapse ">
                <ul class="sidebar-menu" id="nav-accordion">

                    <li class="mt">
                        <a href="viewpayments.php">
                            <span style="font-weight: bold">View Payment Donations</span>
                        </a>
                    </li>
                    <li class="mt">
                        <a href="viewdonations.php">
                            <span style="font-weight: bold">View Other Donations</span>
                        </a>
                    </li>
                    <li class="mt">
                        <a href="events_dash.php">
                            <span style="font-weight: bold">Upload Donated Pictures</span>
                        </a>
                    </li>
                    <li class="mt">
                        <a href="viewjoiners.php">
                            <span style="font-weight: bold">View Joiners Details</span>
                        </a>
                    </li>
                </ul>
            </div>
        </aside>