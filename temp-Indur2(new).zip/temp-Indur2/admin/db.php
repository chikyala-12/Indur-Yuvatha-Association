<?php 
	$con=mysqli_connect("localhost","root","","indur");
	if(!$con)
	{
		echo "Connection is not Successfully";
	}
?>