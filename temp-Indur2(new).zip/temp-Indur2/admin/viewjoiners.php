<?php
include('includes/sidebar.php');
?>

<section id="main-content">
    <section class="wrapper">
        <h3><i class="fa fa-angle-right"></i>View Donations</h3>
        <div class="row">

            <?php include('db.php'); ?>
            <?php include('header.php'); ?>

            <body>


                <div class="row-fluid">
                    <div class="span12">
                        <div class="container">


                            <table cellpadding="0" cellspacing="0" border="0" class="table table-striped table-bordered"
                                id="example">

                                <thead>
                                    <tr>
                                        <th style="text-align:center;">SNO</th>
                                        <th style="text-align:center;">First Name</th>
                                        <th style="text-align:center;">Last Name</th>
                                        <th style="text-align:center;">Email</th>
                                        <th style="text-align:center;">Password</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php

                                    $result = mysqli_query($con, "select * from joinus order by id ASC") or die(mysqli_error($con));
                                    while ($row = mysqli_fetch_array($result)) {
                                        $id = $row['id'];
                                    ?>
                                    <tr>

                                        <td style="text-align:center; word-break:break-all; width:300px;">
                                            <?php echo $row['id']; ?></td>
                                        <td style="text-align:center; word-break:break-all; width:300px;">
                                            <?php echo $row['firstname']; ?></td>
                                        <td style="text-align:center; word-break:break-all; width:300px;">
                                            <?php echo $row['lastname']; ?></td>
                                        <td style="text-align:center; word-break:break-all; width:300px;">
                                            <?php echo $row['email']; ?></td>
                                        <td style="text-align:center; word-break:break-all; width:300px;">
                                            <?php echo $row['password']; ?></td>



                        </div>
                        </tr>

                        <!-- Modal Bigger Image -->


                        <?php } ?>
                        </tbody>
                        </table>



                    </div>
                </div>
        </div>
        </div>
    </section>
</section>
</section>
<script src="assets/js/jquery.js"></script>
<script src="assets/js/bootstrap.min.js"></script>
<script class="include" type="text/javascript" src="assets/js/jquery.dcjqaccordion.2.7.js"></script>
<script src="assets/js/jquery.scrollTo.min.js"></script>
<script src="assets/js/jquery.nicescroll.js" type="text/javascript"></script>
<script src="assets/js/common-scripts.js"></script>
<script>
$(function() {
    $('select.styled').customSelect();
});
</script>

</body>

</html>