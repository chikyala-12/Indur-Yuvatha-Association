<?php
include('includes/sidebar.php'); 
?>

      <section id="main-content">
          <section class="wrapper">
          	<h3><i class="fa fa-angle-right"></i>View Donations of Payments</h3>
							<div class="row">

<?php include('db.php'); ?>
<?php include('header.php'); ?>
<body>


    <div class="row-fluid">
        <div class="span12">


         

            <div class="container">
    

                        <table cellpadding="0" cellspacing="0" border="0" class="table table-striped table-bordered" id="example">
                           
                            <thead>
                                <tr>
                                    <th style="text-align:center;" >SNO</th>
                                    <th style="text-align:center;">Full Name</th>
                                     <th style="text-align:center;">Email</th>                               
									<th style="text-align:center;">Address</th>
									<th style="text-align:center;" >Contact</th>
									<th style="text-align:center;" >State</th>
									<th style="text-align:center;" >Zipcode</th>
                                    <th style="text-align:center;">Amount</th>                                                                 
									<th style="text-align:center;">Action</th>
                                </tr>
                            </thead>
                            <tbody>
								<?php
								
								$result= mysqli_query($con,"select * from donationpay order by sno DESC" ) or die (mysqli_error($con));
								while ($row= mysqli_fetch_array ($result) ){
								$id=$row['sno'];
								?>
								<tr>
								
                                                               <td style="text-align:center; word-break:break-all; width:300px;"> <?php echo $row ['sno']; ?></td>
                                                                 <td style="text-align:center; word-break:break-all; width:300px;"> <?php echo $row ['fullname']; ?></td>
                                                                 <td style="text-align:center; word-break:break-all; width:300px;"> <?php echo $row ['email']; ?></td>
																 <td style="text-align:center; word-break:break-all; width:300px;"> <?php echo $row ['address']; ?></td>
																 <td style="text-align:center; word-break:break-all; width:300px;"> <?php echo $row ['contact']; ?></td>
																 <td style="text-align:center; word-break:break-all; width:300px;"> <?php echo $row ['state']; ?></td>
																 <td style="text-align:center; word-break:break-all; width:300px;"> <?php echo $row ['zip']; ?></td>
																 <td style="text-align:center; word-break:break-all; width:300px;"> <?php echo $row ['amount']; ?></td>

                                                         
								<td style="text-align:center; width:350px;">
<!--									<a href="edit.php<?php echo '?id='.$id; ?>" class="btn btn-info">Edit</a>-->
									 <a href="#delete<?php echo $id;?>"  data-toggle="modal"  class="btn btn-danger" >Delete </a>
								</td>	
										<!-- Modal -->
								<div id="delete<?php  echo $id;?>" class="modal hide fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
								<div class="modal-header">
								<h3 id="myModalLabel">Delete</h3>
								</div>
								<div class="modal-body">
								<p><div class="alert alert-danger">Are you Sure you want Delete?</p>
								</div>
								<hr>
								<div class="modal-footer">
								<button class="btn btn-inverse" data-dismiss="modal" aria-hidden="true">No</button>
								<a href="pay_delete.php<?php echo '?s_no='.$id; ?>" class="btn btn-danger">Yes</a>
								</div>
								</div>
								</div>
								</tr>

								<!-- Modal Bigger Image -->
								

								<?php } ?>  
                            </tbody>
                        </table>


          
        </div>
        </div>
        </div>
    </div>
		</section>
      </section
  ></section>
    <script src="assets/js/jquery.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
    <script class="include" type="text/javascript" src="assets/js/jquery.dcjqaccordion.2.7.js"></script>
    <script src="assets/js/jquery.scrollTo.min.js"></script>
    <script src="assets/js/jquery.nicescroll.js" type="text/javascript"></script>
    <script src="assets/js/common-scripts.js"></script>
  <script>
      $(function(){
          $('select.styled').customSelect();
      });

  </script>

  </body>
</html>

