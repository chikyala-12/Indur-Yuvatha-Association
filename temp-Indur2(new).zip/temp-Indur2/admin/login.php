<?php
if (isset($_POST['signin'])) {
  session_start();
  error_reporting(0);
  include 'db.php';
  $username = $_POST['id'];
  $password = $_POST['pass'];

  $ret = mysqli_query($con, "SELECT * FROM admin WHERE Username='$username' and Password='$password'");
  $num = mysqli_fetch_array($ret);
  if ($num > 0) {
    $_SESSION['alogin'] = $_POST['id'];
    $_SESSION['id'] = $num['id'];
    header("location:dashboard.php");
  } else {
    echo "<script>alert('invalid Details');window.location ='login.php'</script>";
  }
}

?>

<html>

<head>

    <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
    <script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <!------ Include the above in your HEAD tag ---------->
    <style>
    <!-- body#LoginForm{ background-image:url("https://hdwallsource.com/img/2014/9/blur-26347-27038-hd-wallpapers.jpg"); background-repeat:no-repeat; background-position:center; background-size:cover; padding:10px;}
    -->
    body#LoginForm
    {
    /*
    background-image:url("assets/3d-fedora-linux-wallpaper-51275-52971-hd-wallpapers.jpg");
    */
    background-repeat:no-repeat;
    background-position:center;
    background-size:cover;
    padding:10px;
    background:
    black;
    }
    .form-heading
    {
    color:#fff;
    font-size:23px;
    }
    .panel
    h2
    {
    color:#444444;
    font-size:18px;
    margin:0
    0
    8px
    0;
    }
    .panel
    p
    {
    font-size:14px;
    margin-bottom:30px;
    line-height:24px;
    }
    .login-form
    .form-control
    {
    border:
    3px
    solid
    orange;
    border-radius:
    4px;
    font-size:
    14px;
    height:
    50px;
    line-height:
    50px;
    }
    .main-div
    {
    border:
    8px
    groove
    orange;
    border-radius:
    8px;
    margin:
    10px
    auto
    30px;
    max-width:
    38%;
    padding:
    50px
    70px
    70px
    71px;
    }
    button.btn.btn-lg.btn-outline-warning
    {
    margin-top:
    33px;
    /*
    padding:
    20px;
    */
    }
    .login-form
    .form-group
    {
    margin-bottom:10px;
    }
    .panel
    h2
    {
    color:
    #444444;
    font-size:
    32px;
    padding:
    34px;
    /*
    margin-top:
    -12px
     !important;
    */
    margin:
    0
    0
    8px
    0;
    }
    .login-form
    {
    text-align:center;
    }
    .forgot
    a
    {
    color:
    #777777;
    font-size:
    14px;
    text-decoration:
    underline;
    }
    .login-form
    .btn.btn-primary
    {
    background:
    #f0ad4e
    none
    repeat
    scroll
    0
    0;
    border-color:
    #f0ad4e;
    color:
    #ffffff;
    font-size:
    14px;
    width:
    100%;
    height:
    50px;
    line-height:
    50px;
    padding:
    0;
    }
    .forgot
    {
    text-align:
    left;
    margin-bottom:30px;
    }
    .botto-text
    {
    color:
    #ffffff;
    font-size:
    14px;
    margin:
    auto;
    }
    .login-form
    .btn.btn-primary.reset
    {
    background:
    #ff9900
    none
    repeat
    scroll
    0
    0;
    }
    .back
    {
    text-align:
    left;
    margin-top:10px;
    }
    .back
    a
    {
    color:
    #444444;
    font-size:
    13px;
    text-decoration:
    none;
    }

    </style>
</head>

<body id="LoginForm" calss="bg-dark-100">
    <div class="container">
        <h1 class="form-heading text-warning"> Admin login Form</h1>
        <div class="login-form">
            <div class="main-div">
                <div class="panel">
                    <h2 class="text-warning">Admin Login</h2>
                </div>
                <form id="Login" method="post" action="">

                    <div class="form-group">


                        <input type="text" class="form-control" name="id" id="inputEmail" placeholder="username"
                            required maxlength="12">

                    </div>

                    <div class="form-group">

                        <input type="password" class="form-control" name="pass" id="inputPassword"
                            placeholder="Password" required maxlength="20">

                    </div>

                    <button type="submit" name="signin" class="btn  btn-lg btn-outline-warning">Login</button>

                </form>
            </div>
        </div>
    </div>
    </div>


</body>

</html>