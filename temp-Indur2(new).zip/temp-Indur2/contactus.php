<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>DotCom - Creative Agency Website Template</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="Free HTML Templates" name="keywords">
    <meta content="Free HTML Templates" name="description">

    <!-- Favicon -->
    <link href="img/favicon.ico" rel="icon">
    <link rel="stylesheet" href="path/to/font-awesome/css/font-awesome.min.css">
    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Raleway:wght@400;500;600;700;800;900&display=swap"
        rel="stylesheet">

    <!-- Font Awesome -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.0/css/all.min.css" rel="stylesheet">

    <!-- Libraries Stylesheet -->
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">

    <!-- Customized Bootstrap Stylesheet -->
    <link href="css/style.css" rel="stylesheet">
    <style>
    h1.m-0.text-white.display-4 {
        font-size: 31px;
    }

    img.img-fluid.slider-1 {
        width: 1515px !important;
    }

    .container-fluid.nav-bar.p-0 {
        margin: 0px !important;
        background: black;
    }

    fieldset.jionus {
        border: 23px solid orange !important;
        width: 260px;
        padding: 20px;
        margin-top: 100px;
    }

    fieldset.contact {
        border: 23px solid orange !important;
        width: 260px;
        padding: 20px;
        margin-top: 100px;
    }

    .jionus-container {
        margin-left: 394px;
    }

    a.logo-brand {
        margin-left: 52px;
        padding: 16px;
    }
    </style>
</head>

<body>
    <!-- Navbar Start -->
    <div class="container-fluid nav-bar p-0">
        <div class="container-lg p-0">
            <nav class="navbar navbar-expand-lg bg-secondary navbar-dark">
                <a href="index.html" class="navbar-brand">
                    <h1 class="m-0 text-white display-4"><span class="text-primary">indur</span>yuvutha<span
                            class="text-primary">Association</span></h1>
                </a>
                <button type="button" class="navbar-toggler" data-toggle="collapse" data-target="#navbarCollapse">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse justify-content-between" id="navbarCollapse">
                    <div class="navbar-nav ml-auto py-0">
                        <a href="index.html" class="nav-item nav-link active">Home</a>
                        <a href="about.html" class="nav-item nav-link">About</a>
                        <a href="service.html" class="nav-item nav-link">Services</a>
                        <a href="Gallery.php" class="nav-item nav-link">Gallery</a>
                        <div class="nav-item dropdown">
                            <a href="#" class="nav-link dropdown-toggle" data-toggle="dropdown">Media</a>
                            <div class="dropdown-menu border-0 rounded-0 m-0">
                                <a href="https://www.youtube.com/channel/UCMdsIOJwpBNHqgA5rgihR-Q"
                                    class="dropdown-item">videos</a>
                                <a href="news.html" class="dropdown-item">News</a>
                            </div>
                        </div>
                        <div class="nav-item dropdown">
                            <a href="Donation.php" class="nav-link dropdown-toggle" data-toggle="dropdown">Donation</a>
                            <div class="dropdown-menu border-0 rounded-0 m-0">
                                <a href="Donation.php" class="dropdown-item">Money</a>
                                <a href="donation2.php" class="dropdown-item">Other</a>
                            </div>
                        </div>
                        <a href="./contactus.php" class="nav-item nav-link">Join us</a>
                        <a href="./admin/login.php" class="nav-item nav-link">Admin</a>
                    </div>
                </div>
            </nav>
        </div>
    </div>
    <!-- Navbar End -->

    <!------------Account page-------------->
    <div class="account-page bg-dark">
        <div class="container">
            <div class="row">

                <div class="col-2">
                    <div class="form-container jionus-container" action="login.php" class="mx-auto d-block">
                        <div class="form-btn">
                            <span onclick="login()">Join </span>
                            <span onclick="register()">Contact </span>
                            <hr id="Indicator">
                        </div>
                        <form id="LoginForm" method="POST" action="">
                            <fieldset class="jionus">
                                <input type="text" name="firstname" placeholder="first name" class="form-control"><br>
                                <input type="text" name="lastname" placeholder="Last name" class="form-control"><br>
                                <input type="text" name="email" placeholder="email" class="form-control"><br>
                                <input type="password" name="password" placeholder="password" class="form-control"><br>


                                <input type="submit" class="btn btn-outline-warning" name="submit">

                            </fieldset>

                        </form>
                        <!-- <form id="RegForm" method="POST" action="">
                            <fieldset class="contact">
                                <input type="text" placeholder="Full name">
                                <input type="email" placeholder="Email">
                                <input type="password" placeholder="Password">
                                <input type="text" placeholder="Type something .....">
                                <input type="submit" class="btn">
                                <i class="fa fa-phone"> +9876543210</i>

                            </fieldset>


                        </form>-->

                    </div>
                </div>

                <div class="container-fluid bg-dark pt-5 text-white">
                    <div class="row pt-5">
                        <div class="col-lg-3 col-md-6 mb-5">
                            <a href="index.html" class="logo-brand">
                                <img src="img/logo3.png" height="80px" width="80px">
                            </a>
                            <p>Our purpose is to Sustainbly Make the poverty end with help of many people</p>
                            <div class="d-flex justify-content-start mt-4">
                                <a class="btn btn-outline-primary rounded-circle text-center mr-2 px-0"
                                    style="width: 38px; height: 38px;" href="https://twitter.com/inizamabad"><i
                                        class="fab fa-twitter"></i></a>
                                <a class="btn btn-outline-primary rounded-circle text-center mr-2 px-0"
                                    style="width: 38px; height: 38px;"
                                    href="https://www.facebook.com/Indur-Yuvatha-Association-Nzb-115054433285509/"><i
                                        class="fab fa-facebook-f"></i></a>
                                <a class="btn btn-outline-primary rounded-circle text-center mr-2 px-0"
                                    style="width: 38px; height: 38px;" href="#"><i class="fa-brands fa-youtube"></i></a>
                                <a class="btn btn-outline-primary rounded-circle text-center mr-2 px-0"
                                    style="width: 38px; height: 38px;"
                                    href="https://instagram.com/induryuvatha?igshid=YmMyMTA2M2Y="><i
                                        class="fab fa-instagram"></i></a>
                            </div>
                        </div>
                        <div class="col-lg-3 col-md-6 mb-5">
                            <h5 class="font-weight-bold text-primary mb-4">Quick Links</h5>
                            <div class="d-flex flex-column justify-content-start">
                                <a class="text-white mb-2" href="#"><i
                                        class="fa fa-angle-right text-primary mr-2"></i>Home</a>
                                <a class="text-white mb-2" href="#"><i
                                        class="fa fa-angle-right text-primary mr-2"></i>About Us</a>
                                <a class="text-white mb-2" href="#"><i
                                        class="fa fa-angle-right text-primary mr-2"></i>Services</a>
                                <a class="text-white mb-2" href="#"><i
                                        class="fa fa-angle-right text-primary mr-2"></i>Pricing</a>
                                <a class="text-white" href="#"><i
                                        class="fa fa-angle-right text-primary mr-2"></i>Contact Us</a>
                            </div>
                        </div>
                        <div class="col-lg-3 col-md-6 mb-5">
                            <h5 class="font-weight-bold text-primary mb-4">Popular Links</h5>
                            <div class="d-flex flex-column justify-content-start">
                                <a class="text-white mb-2" href="#"><i
                                        class="fa fa-angle-right text-primary mr-2"></i>Home</a>
                                <a class="text-white mb-2" href="#"><i
                                        class="fa fa-angle-right text-primary mr-2"></i>About Us</a>
                                <a class="text-white mb-2" href="#"><i
                                        class="fa fa-angle-right text-primary mr-2"></i>Services</a>
                                <a class="text-white mb-2" href="#"><i
                                        class="fa fa-angle-right text-primary mr-2"></i>Pricing</a>
                                <a class="text-white" href="#"><i
                                        class="fa fa-angle-right text-primary mr-2"></i>Contact Us</a>
                            </div>
                        </div>
                        <div class="col-lg-3 col-md-6 mb-5">
                            <h5 class="font-weight-bold text-primary mb-4">Get In Touch</h5>
                            <p>Together we can make a diffrence</p>
                            <p><i class="fa fa-map-marker-alt text-primary mr-2"></i>Nizamabad , Telangana ,503224</p>
                            <p><i class="fa fa-phone-alt text-primary mr-2"></i>+8897213286</p>
                            <p><i class="fa fa-envelope text-primary mr-2"></i>Madhukurisaibabu@gmail.com</p>
                        </div>
                    </div>
                </div>
                <div class="container-fluid py-4 px-sm-3 px-md-5">
                    <p class="m-0 text-center">
                        &copy; <a class="font-weight-semi-bold" href="#" class="text-white">indure yuvutha
                            association</a>

                        <a class="font-weight-semi-bold" href="https://htmlcodex.com"> </a>
                    </p>
                </div>
                <!-- Footer End -->



                <?php
                if (isset($_POST['submit'])) {

                    $con = mysqli_connect("localhost", "root", "", "indur");
                    $fname = $_POST['firstname'];
                    $lname = $_POST['lastname'];
                    $email = $_POST['email'];
                    $pswd = $_POST['password'];
                    $query = "INSERT INTO joinus(firstname,lastname,email,password) VALUES ('$fname','$lname','$email','$pswd')";
                    $result = mysqli_query($con, $query) or die(mysqli_error($con));
                    if (mysqli_affected_rows($con) > 0) {
                        echo "<script>alert('Thanks for Joining with us, We will reach you back,Thank You');
        window.location.href='contactus.php';</script>";
                    }
                }
                ?>


            </div>
        </div>

    </div>

    <!---------------------javascript-------------->

    <!---------------js for toggle form--------------->
    <script>
    var LoginForm = document.getElementById("LoginForm");
    var RegForm = document.getElementById("RegForm");
    var Indicator = document.getElementById("Indicator");

    function register() {
        RegForm.style.transform = "translateX(0px)";
        LoginForm.style.transform = "translateX(0px)";
        Indicator.style.transform = "translateX(100px)";
    }

    function login() {
        RegForm.style.transform = "translateX(300px)";
        LoginForm.style.transform = "translateX(300px)";
        Indicator.style.transform = "translateX(0px)";
    }
    </script>

</html>