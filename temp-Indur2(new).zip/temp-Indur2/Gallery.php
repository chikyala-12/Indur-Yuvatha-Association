<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>DotCom - Creative Agency Website Template</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="Free HTML Templates" name="keywords">
    <meta content="Free HTML Templates" name="description">

    <!-- Favicon -->
    <link href="img/favicon.ico" rel="icon">
    <link rel="stylesheet" href="path/to/font-awesome/css/font-awesome.min.css">
    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Raleway:wght@400;500;600;700;800;900&display=swap"
        rel="stylesheet">

    <!-- Font Awesome -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.0/css/all.min.css" rel="stylesheet">

    <!-- Libraries Stylesheet -->
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">

    <!-- Customized Bootstrap Stylesheet -->
    <link href="css/style.css" rel="stylesheet">
    <style>
    h1.m-0.text-white.display-4 {
        font-size: 31px;
    }

    img.img-fluid.slider-1 {
        width: 1515px !important;
    }

    .container-fluid.nav-bar.p-0 {
        background: black !important;
    }
    </style>
</head>

<body>
    <!-- Navbar Start -->
    <div class="container-fluid nav-bar p-0">
        <div class="container-lg p-0">
            <nav class="navbar navbar-expand-lg bg-secondary navbar-dark">
                <a href="index.html" class="navbar-brand">
                    <h1 class="m-0 text-white display-4"><span class="text-primary">indur</span>yuvutha<span
                            class="text-primary">Association</span></h1>
                </a>
                <button type="button" class="navbar-toggler" data-toggle="collapse" data-target="#navbarCollapse">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse justify-content-between" id="navbarCollapse">
                    <div class="navbar-nav ml-auto py-0">
                        <a href="index.html" class="nav-item nav-link active">Home</a>
                        <a href="about.html" class="nav-item nav-link">About</a>
                        <a href="service.html" class="nav-item nav-link">Services</a>
                        <a href="Gallery.php" class="nav-item nav-link">Gallery</a>
                        <div class="nav-item dropdown">
                            <a href="#" class="nav-link dropdown-toggle" data-toggle="dropdown">Media</a>
                            <div class="dropdown-menu border-0 rounded-0 m-0">
                                <a href="https://www.youtube.com/channel/UCMdsIOJwpBNHqgA5rgihR-Q"
                                    class="dropdown-item">videos</a>
                                <a href="news.html" class="dropdown-item">News</a>
                            </div>
                        </div>
                        <div class="nav-item dropdown">
                            <a href="Donation.php" class="nav-link dropdown-toggle" data-toggle="dropdown">Donation</a>
                            <div class="dropdown-menu border-0 rounded-0 m-0">
                                <a href="Donation.php" class="dropdown-item">Money</a>
                                <a href="donation2.php" class="dropdown-item">Other</a>
                            </div>
                        </div>
                        <a href="./contactus.php" class="nav-item nav-link">Join us</a>
                        <a href="./admin/login.php" class="nav-item nav-link">Admin</a>
                    </div>
                </div>
            </nav>
        </div>
    </div>
    <!-- Navbar End -->



    <div class="row">
        <div class="col-75">
            <div class="container">
                <form action="" method="POST" enctype="multipart/form-data">
                    <section class="about inner padding-lg">
                        <div class="container">
                            <div class="row">
                                <div class="col-md-12 ">

                                    <div class="gallery ">


                                        <?php
                                        //Include database configuration file

                                        //DB details
                                        include 'admin/db.php';

                                        //Create connection and select DB

                                        //get images from database
                                        $query = mysqli_query($con, "SELECT * FROM donationupload ORDER BY s_no DESC");


                                        while ($row = mysqli_fetch_assoc($query)) {
                                            $imageThumbURL = 'admin/upload/' . $row["location"];
                                            $imageURL = 'admin/upload/' . $row["location"];
                                        ?>



                                        <a href="<?php echo $imageURL; ?>" data-fancybox="group"
                                            data-caption="<?php echo $row["location"]; ?>">
                                            <img class="img1" src="admin/upload/<?php echo $row['location']; ?>" />

                                        </a>
                                        <?php }
                                        ?>
                                    </div>



                                </div>
                            </div>
                        </div>
                    </section>

                </form>
            </div>
        </div>

    </div>

    <!-- Back to Top -->
    <a href="#" class="btn btn-lg btn-primary back-to-top"><i class="fa fa-angle-up"></i></a>


    <!-- JavaScript Libraries -->
    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.bundle.min.js"></script>
    <script src="lib/easing/easing.min.js"></script>
    <script src="lib/waypoints/waypoints.min.js"></script>
    <script src="lib/counterup/counterup.min.js"></script>
    <script src="lib/owlcarousel/owl.carousel.min.js"></script>

    <!-- Contact Javascript File -->
    <script src="mail/jqBootstrapValidation.min.js"></script>
    <script src="mail/contact.js"></script>

    <!-- Template Javascript -->
    <script src="js/main.js"></script>



</html>