<!DOCTYPE html>
<?php include('db.php') ?>
<html lang="en">


<head>
    <meta charset="utf-8">
    <title>DotCom - Creative Agency Website Template</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="Free HTML Templates" name="keywords">
    <meta content="Free HTML Templates" name="description">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">


    <!-- Favicon -->
    <link href="img/favicon.ico" rel="icon">

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Raleway:wght@400;500;600;700;800;900&display=swap"
        rel="stylesheet">

    <!-- Font Awesome -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.0/css/all.min.css" rel="stylesheet">

    <!-- Libraries Stylesheet -->
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">

    <!-- Customized Bootstrap Stylesheet -->
    <link href="css/style.css" rel="stylesheet">
    <style>
    .certificates-end {}

    * {
        box-sizing: border-box;
    }

    .row {
        display: -ms-flexbox;
        /* IE10 */
        display: flex;
        -ms-flex-wrap: wrap;
        /* IE10 */
        flex-wrap: wrap;
        margin: 0 -16px;
    }

    .col-25 {
        -ms-flex: 25%;
        /* IE10 */
        flex: 25%;
    }

    .col-50 {
        -ms-flex: 50%;
        /* IE10 */
        flex: 50%;
    }

    .col-75 {
        -ms-flex: 75%;
        /* IE10 */
        flex: 75%;
    }

    .col-25,
    .col-50,
    .col-75 {
        padding: 0 16px;
    }

    .container {
        background-color: #f2f2f2;
        padding: 5px 20px 15px 20px;
        border: 1px solid lightgrey;
        border-radius: 3px;
    }

    input[type=text] {
        width: 100%;
        margin-bottom: 20px;
        padding: 12px;
        border: 1px solid #ccc;
        border-radius: 3px;
    }

    label {
        margin-bottom: 10px;
        display: block;
    }

    .icon-container {
        margin-bottom: 20px;
        padding: 7px 0;
        font-size: 24px;
    }

    .btn-small {
        width: 100px !important;
    }

    .btn {
        background-color: #04AA6D;
        color: white;
        padding: 12px;
        margin: 10px 0;
        border: none;
        width: 100%;
        border-radius: 3px;
        cursor: pointer;
        font-size: 17px;
    }

    .btn:hover {
        background-color: #45a049;
    }

    a {
        color: #2196F3;
    }

    hr {
        border: 1px solid lightgrey;
    }

    span.price {
        float: right;
        color: grey;
    }

    /* Responsive layout - when the screen is less than 800px wide, make the two columns stack on top of each other instead of next to each other (also change the direction - make the "cart" column go on top) */
    @media (max-width: 800px) {
        .row {
            flex-direction: column-reverse;
        }

        .col-25 {
            margin-bottom: 20px;
        }
    }
    </style>
</head>

<body>

    <!-- Navbar Start -->
    <div class="container-fluid nav-bar p-0">
        <div class="container-lg p-0">
            <nav class="navbar navbar-expand-lg bg-secondary navbar-dark">
                <a href="index.html" class="navbar-brand">
                    <h1 class="m-0 text-white display-4"><span class="text-primary">indur</span>yuvutha<span
                            class="text-primary">Association</span></h1>
                </a>
                <button type="button" class="navbar-toggler" data-toggle="collapse" data-target="#navbarCollapse">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse justify-content-between" id="navbarCollapse">
                    <div class="navbar-nav ml-auto py-0">
                        <a href="index.html" class="nav-item nav-link active">Home</a>
                        <a href="about.html" class="nav-item nav-link">About</a>
                        <a href="service.html" class="nav-item nav-link">Services</a>
                        <a href="Gallery.php" class="nav-item nav-link">Gallery</a>
                        <div class="nav-item dropdown">
                            <a href="#" class="nav-link dropdown-toggle" data-toggle="dropdown">Media</a>
                            <div class="dropdown-menu border-0 rounded-0 m-0">
                                <a href="https://www.youtube.com/channel/UCMdsIOJwpBNHqgA5rgihR-Q" class="dropdown-item">videos</a>
                                <a href="news.html" class="dropdown-item">News</a>
                            </div>
                        </div>
                        <div class="nav-item dropdown">
                            <a href="#" class="nav-link dropdown-toggle" data-toggle="dropdown">Donation</a>
                            <div class="dropdown-menu border-0 rounded-0 m-0">
                                <a href="Donation.php" class="dropdown-item">Money</a>
                                <a href="donation2.php" class="dropdown-item">Other</a>
                            </div>
                        </div>
                        <a href="contactus.php" class="nav-item nav-link">Join us</a>
                        <a href="./admin/login.php" class="nav-item nav-link">Admin</a>
                    </div>
                </div>
            </nav>
        </div>
    </div>
    <!-- Navbar End -->


    <!-- Page Header Start -->
    <div
        class="container-fluid page-header d-flex flex-column align-items-center justify-content-center pt-0 pt-lg-5 mb-5">
        <h1 class="display-4 text-white mb-3 mt-0 mt-lg-5">Donations</h1>
        <div class="d-inline-flex text-white">
            <p class="m-0"><a class="text-white" href="">Home</a></p>
            <p class="m-0 px-2">/</p>
            <p class="m-0">Donations</p>
        </div>
    </div>
    <!-- Page payment Start -->
    <div class="row">
        <div class="col-75">
            <div class="container">
                <form action="" method="POST" enctype="multipart/form-data">

                    <div class="row">
                        <div class="col-50">
                            <h3>Billing Address</h3>
                            <label for="fname"><i class="fa fa-user"></i> Full Name</label>
                            <input type="text" name="fullname" placeholder="John M. Doe">
                            <label for="email"><i class="fa fa-envelope"></i> Email</label>
                            <input type="text" name="email" placeholder="john@example.com">
                            <label for="adr"><i class="fa fa-address-card-o"></i> Address</label>
                            <input type="text" name="address" placeholder="542 W. 15th Street">
                            <label for="city"><i class="fa fa-institution"></i> Contact</label>
                            <input type="text" name="contact" placeholder="9123456789">
                            <div class="row">
                                <div class="col-50">
                                    <label for="state">State</label>
                                    <input type="text" name="state" placeholder="NY">
                                </div>
                                <div class="col-50">
                                    <label for="zip">Zip</label>
                                    <input type="text" name="zip" placeholder="100001">
                                </div>
                                <div class="col-50">
                                    <label for="amount">Amount</label>
                                    <input type="text" name="amount" placeholder="Enter Amount">
                                </div>
                            </div>
                        </div>

                        <div class="col-50">
                            <h3>Payment</h3>
                            <label for="fname">Accepted Cards</label>
                            <div class="icon-container">
                                <i class="fa fa-cc-visa" style="color:navy;"></i>
                                <i class="fa fa-cc-amex" style="color:blue;"></i>
                                <i class="fa fa-cc-mastercard" style="color:red;"></i>
                                <i class="fa fa-cc-discover" style="color:orange;"></i>
                            </div>
                            <label for="cname">Name on Card</label>
                            <input type="text" name="cardname" placeholder="John More Doe">
                            <label for="ccnum">Credit card number</label>
                            <input type="text" name="cardnumber" placeholder="1111-2222-3333-4444">
                            <label for="expmonth">Exp Month</label>
                            <input type="text" name="expmonth" placeholder="September">
                            <div class="row">
                                <div class="col-50">
                                    <label for="expyear">Exp Year</label>
                                    <input type="text" name="expyear" placeholder="2018">
                                </div>
                                <div class="col-50">
                                    <label for="cvv">CVV</label>
                                    <input type="text" name="cvv" placeholder="352">
                                </div>
                            </div>
                        </div>

                        <input type="submit" name="submit" value="Submit" class="btn">
                    </div>
                    <?php
                    if (isset($_POST['submit'])) {

                        $name = $_POST['fullname'];
                        $email = $_POST['email'];
                        $address = $_POST['address'];
                        $contact = $_POST['contact'];

                        $state = $_POST['state'];
                        $zip = $_POST['zip'];
                        $amount = $_POST['amount'];
                        $cardname = $_POST['cardname'];

                        $cardnumber = $_POST['cardnumber'];
                        $expmonth = $_POST['expmonth'];
                        $expyear = $_POST['expyear'];
                        $cvv = $_POST['cvv'];

                        $query = "INSERT INTO donationpay(fullname,email,address,contact,state,zip,amount,cardname,cardnumber,expmonth,expyear,cvv) VALUES('$name','$email','$address','$contact','$state','$zip','$amount','$cardname','$cardnumber','$expmonth','$expyear','$cvv')";
                        $result = mysqli_query($con, $query) or die(mysqli_error($con));
                        if (mysqli_affected_rows($con) > 0) {
                            echo "<script>alert('SUCCESSFULLY STORED INFO');
        window.location.href='Donation.php';</script>";
                        }
                    }
                    ?>

                </form>
            </div>
        </div>






        <!-- Footer Start -->
        <div class="container-fluid bg-secondary text-white mt-5 pt-5 px-sm-3 px-md-5">
            <div class="row pt-5">
                <div class="col-lg-3 col-md-6 mb-5">
                    <a href="index.html" class="navbar-brand">
                        <img src="img/logo3.png" height="100px" width="100px">
                    </a>
                    <p>Our purpose is to Sustainbly Make the poverty end with help of many people</p>
                    <div class="d-flex justify-content-start mt-4">
                        <a class="btn btn-outline-primary rounded-circle text-center mr-2 px-0"
                            style="width: 38px; height: 38px;" href="https://twitter.com/inizamabad"><i
                                class="fab fa-twitter"></i></a>
                        <a class="btn btn-outline-primary rounded-circle text-center mr-2 px-0"
                            style="width: 38px; height: 38px;"
                            href="https://www.facebook.com/Indur-Yuvatha-Association-Nzb-115054433285509/"><i
                                class="fab fa-facebook-f"></i></a>
                        <a class="btn btn-outline-primary rounded-circle text-center mr-2 px-0"
                            style="width: 38px; height: 38px;" href="#"><i class="fab fa-linkedin-in"></i></a>
                        <a class="btn btn-outline-primary rounded-circle text-center mr-2 px-0"
                            style="width: 38px; height: 38px;"
                            href="https://instagram.com/induryuvatha?igshid=YmMyMTA2M2Y="><i
                                class="fab fa-instagram"></i></a>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 mb-5">
                    <h5 class="font-weight-bold text-primary mb-4">Quick Links</h5>
                    <div class="d-flex flex-column justify-content-start">
                        <a class="text-white mb-2" href="#"><i class="fa fa-angle-right text-primary mr-2"></i>Home</a>
                        <a class="text-white mb-2" href="#"><i class="fa fa-angle-right text-primary mr-2"></i>About
                            Us</a>
                        <a class="text-white mb-2" href="#"><i
                                class="fa fa-angle-right text-primary mr-2"></i>Services</a>
                        <a class="text-white mb-2" href="#"><i
                                class="fa fa-angle-right text-primary mr-2"></i>Pricing</a>
                        <a class="text-white" href="#"><i class="fa fa-angle-right text-primary mr-2"></i>Contact Us</a>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 mb-5">
                    <h5 class="font-weight-bold text-primary mb-4">Popular Links</h5>
                    <div class="d-flex flex-column justify-content-start">
                        <a class="text-white mb-2" href="#"><i class="fa fa-angle-right text-primary mr-2"></i>Home</a>
                        <a class="text-white mb-2" href="#"><i class="fa fa-angle-right text-primary mr-2"></i>About
                            Us</a>
                        <a class="text-white mb-2" href="#"><i
                                class="fa fa-angle-right text-primary mr-2"></i>Services</a>
                        <a class="text-white mb-2" href="#"><i
                                class="fa fa-angle-right text-primary mr-2"></i>Pricing</a>
                        <a class="text-white" href="#"><i class="fa fa-angle-right text-primary mr-2"></i>Contact Us</a>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 mb-5">
                    <h5 class="font-weight-bold text-primary mb-4">Get In Touch</h5>
                    <p>Together we can make a diffrence</p>
                    <p><i class="fa fa-map-marker-alt text-primary mr-2"></i>Nizamabad , Telangana ,503224</p>
                    <p><i class="fa fa-phone-alt text-primary mr-2"></i>+8897213286</p>
                    <p><i class="fa fa-envelope text-primary mr-2"></i>Madhukurisaibabu@gmail.com</p>
                </div>
            </div>
        </div>
        <div class="container-fluid py-4 px-sm-3 px-md-5">
            <p class="m-0 text-center">
                &copy; <a class="font-weight-semi-bold" href="#">Your Site Name</a>. All Rights Reserved. Designed by
                <a class="font-weight-semi-bold" href="https://htmlcodex.com">A7-Batch</a>
            </p>
        </div>
        <!-- Footer End -->


        <!-- Back to Top -->
        <a href="#" class="btn  btn-primary back-to-top btn-small"><i class="fa fa-angle-up"></i></a>


        <!-- JavaScript Libraries -->
        <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.bundle.min.js"></script>
        <script src="lib/easing/easing.min.js"></script>
        <script src="lib/waypoints/waypoints.min.js"></script>
        <script src="lib/counterup/counterup.min.js"></script>
        <script src="lib/owlcarousel/owl.carousel.min.js"></script>

        <!-- Contact Javascript File -->
        <script src="mail/jqBootstrapValidation.min.js"></script>
        <script src="mail/contact.js"></script>

        <!-- Template Javascript -->
        <script src="js/main.js"></script>
</body>

</html>