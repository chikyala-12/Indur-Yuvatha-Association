<!DOCTYPE html>
<?php
include('db.php');
?>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>DotCom - Creative Agency Website Template</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="Free HTML Templates" name="keywords">
    <meta content="Free HTML Templates" name="description">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">


    <!-- Favicon -->
    <link href="img/favicon.ico" rel="icon">

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Raleway:wght@400;500;600;700;800;900&display=swap"
        rel="stylesheet">

    <!-- Font Awesome -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.0/css/all.min.css" rel="stylesheet">

    <!-- Libraries Stylesheet -->
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">

    <!-- Customized Bootstrap Stylesheet -->
    <link href="css/style.css" rel="stylesheet">
    <style>
    * {
        box-sizing: border-box;
    }

    p,
    label {
        font: 1rem 'Fira Sans', sans-serif;
    }

    input {
        margin: .4rem;
    }

    fieldset {
        width: 200px;
    }

    .Radio {
        position: relative;
        left: 30%;
        top: 30px;
    }

    button {
        background-color: blue;
        width: 50%;
        color: orange;
        padding: 15px;
        margin: 10px 0px;
        border: none;
        cursor: pointer;
    }

    form {
        border: 3px solid bisque;
        border-radius: 10px;
        width: 500px;
        margin: auto;
    }

    input[type=text],
    input[type=password] {
        width: 100%;
        margin: 8px 0;
        padding: 12px 20px;
        display: inline-block;
        border: 2px solid palevioletred;
        box-sizing: border-box;
    }

    button:hover {
        opacity: 0.7;
    }

    .cancelbtn {
        width: auto;
        padding: 10px 18px;
        margin: 10px 5px;
    }


    .container-1 {
        height: fit-content;
        width: fit-content;
        padding: 25px;
        background-color: rgb(205, 230, 173);
    }

    .header {
        height: 350px;
    }

    .cancel {
        position: relative;

        left: 70%;

    }
    </style>
</head>

<body>

    <!-- Navbar Start -->
    <div class="container-fluid nav-bar p-0">
        <div class="container-lg p-0">
            <nav class="navbar navbar-expand-lg bg-secondary navbar-dark">
                <a href="index.html" class="navbar-brand">
                    <h1 class="m-0 text-white display-4"><span class="text-primary">indur</span>yuvutha<span
                            class="text-primary">Association</span></h1>
                </a>
                <button type="button" class="navbar-toggler" data-toggle="collapse" data-target="#navbarCollapse">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse justify-content-between" id="navbarCollapse">
                    <div class="navbar-nav ml-auto py-0">
                        <a href="index.html" class="nav-item nav-link active">Home</a>
                        <a href="about.html" class="nav-item nav-link">About</a>
                        <a href="service.html" class="nav-item nav-link">Services</a>
                        <a href="Gallery.php" class="nav-item nav-link">Gallery</a>
                        <div class="nav-item dropdown">
                            <a href="#" class="nav-link dropdown-toggle" data-toggle="dropdown">Media</a>
                            <div class="dropdown-menu border-0 rounded-0 m-0">
                                <a href="https://www.youtube.com/channel/UCMdsIOJwpBNHqgA5rgihR-Q" class="dropdown-item">videos</a>
                                <a href="news.html" class="dropdown-item">News</a>
                            </div>
                        </div>
                        <div class="nav-item dropdown">
                            <a href="#" class="nav-link dropdown-toggle" data-toggle="dropdown">Donation</a>
                            <div class="dropdown-menu border-0 rounded-0 m-0">
                                <a href="Donation.php" class="dropdown-item">Money</a>
                                <a href="donation2.php" class="dropdown-item">Other</a>
                            </div>
                        </div>
                        <a href="contactus.php" class="nav-item nav-link">Join us</a>
                        <a href="./admin/login.php" class="nav-item nav-link">Admin</a>
                    </div>
                </div>
            </nav>
        </div>
    </div>
    <!-- Navbar End -->


    <!-- Page Header Start -->
    <div
        class="container-fluid page-header d-flex flex-column align-items-center justify-content-center pt-0 pt-lg-5 mb-5">
        <h1 class="display-4 text-white mb-3 mt-0 mt-lg-5">Donations</h1>
        <div class="d-inline-flex text-white">
            <p class="m-0"><a class="text-white" href="">Home</a></p>
            <p class="m-0 px-2">/</p>
            <p class="m-0">Services</p>
        </div>
    </div>
    <form action="" method="POST" enctype="multipart/form-data">
        <div class="container-1">
            <legend>Select:</legend>
            <div>
                <input type="radio" name="item" value="Food" checked>
                <label for="food">Food</label>
            </div>
            <div>
                <input type="radio" name="item" value="Cloths">
                <label for="Cloths">Cloths</label>
            </div>
            <div>
                <input type="radio" name="item" value="Both">
                <label for="Both">Both</label>
            </div>
            <label>Name : </label>
            <input type="text" placeholder="Enter name" name="name" required>
            <label>Contact No : </label>
            <input type="text" placeholder="Enter Contact No" name="Contact" required>
            <label>Address : </label>
            <input type="text" placeholder="Enter Address" name="Address" required>
            <input type="submit" name="submit" value="Submit">
        </div>
        <?php
        if (isset($_POST['submit'])) {
            $name = $_POST['name'];
            $contact = $_POST['Contact'];
            $address = $_POST['Address'];
            $item = $_POST['item'];
            $query = "INSERT INTO donation(name,contact,address,item) VALUES ('$name','$contact','$address','$item')";
            $result = mysqli_query($con, $query) or die(mysqli_error($con));
            if (mysqli_affected_rows($con) > 0) {
                echo "<script>alert('SUCCESSFULLY STORED INFO');
        window.location.href='donation2.php';</script>";
            }
        }
        ?>
    </form>


    <!-- Footer Start -->
    <div class="container-fluid bg-secondary text-white mt-5 pt-5 px-sm-3 px-md-5">
        <div class="row pt-5">
            <div class="col-lg-3 col-md-6 mb-5">
                <a href="index.html" class="navbar-brand">
                    <img src="img/logo3.png" height="100px" width="100px">
                </a>
                <p>Our purpose is to Sustainbly Make the poverty end with help of many people</p>
                <div class="d-flex justify-content-start mt-4">
                    <a class="btn btn-outline-primary rounded-circle text-center mr-2 px-0"
                        style="width: 38px; height: 38px;" href="https://twitter.com/inizamabad"><i
                            class="fab fa-twitter"></i></a>
                    <a class="btn btn-outline-primary rounded-circle text-center mr-2 px-0"
                        style="width: 38px; height: 38px;"
                        href="https://www.facebook.com/Indur-Yuvatha-Association-Nzb-115054433285509/"><i
                            class="fab fa-facebook-f"></i></a>
                    <a class="btn btn-outline-primary rounded-circle text-center mr-2 px-0"
                        style="width: 38px; height: 38px;" href="#"><i class="fab fa-linkedin-in"></i></a>
                    <a class="btn btn-outline-primary rounded-circle text-center mr-2 px-0"
                        style="width: 38px; height: 38px;"
                        href="https://instagram.com/induryuvatha?igshid=YmMyMTA2M2Y="><i
                            class="fab fa-instagram"></i></a>
                </div>
            </div>
            <div class="col-lg-3 col-md-6 mb-5">
                <h5 class="font-weight-bold text-primary mb-4">Quick Links</h5>
                <div class="d-flex flex-column justify-content-start">
                    <a class="text-white mb-2" href="#"><i class="fa fa-angle-right text-primary mr-2"></i>Home</a>
                    <a class="text-white mb-2" href="#"><i class="fa fa-angle-right text-primary mr-2"></i>About Us</a>
                    <a class="text-white mb-2" href="#"><i class="fa fa-angle-right text-primary mr-2"></i>Services</a>
                    <a class="text-white mb-2" href="#"><i class="fa fa-angle-right text-primary mr-2"></i>Pricing</a>
                    <a class="text-white" href="#"><i class="fa fa-angle-right text-primary mr-2"></i>Contact Us</a>
                </div>
            </div>
            <div class="col-lg-3 col-md-6 mb-5">
                <h5 class="font-weight-bold text-primary mb-4">Popular Links</h5>
                <div class="d-flex flex-column justify-content-start">
                    <a class="text-white mb-2" href="#"><i class="fa fa-angle-right text-primary mr-2"></i>Home</a>
                    <a class="text-white mb-2" href="#"><i class="fa fa-angle-right text-primary mr-2"></i>About Us</a>
                    <a class="text-white mb-2" href="#"><i class="fa fa-angle-right text-primary mr-2"></i>Services</a>
                    <a class="text-white mb-2" href="#"><i class="fa fa-angle-right text-primary mr-2"></i>Pricing</a>
                    <a class="text-white" href="#"><i class="fa fa-angle-right text-primary mr-2"></i>Contact Us</a>
                </div>
            </div>
            <div class="col-lg-3 col-md-6 mb-5">
                <h5 class="font-weight-bold text-primary mb-4">Get In Touch</h5>
                <p>Together we can make a diffrence</p>
                <p><i class="fa fa-map-marker-alt text-primary mr-2"></i>Nizamabad , Telangana ,503224</p>
                <p><i class="fa fa-phone-alt text-primary mr-2"></i>+8897213286</p>
                <p><i class="fa fa-envelope text-primary mr-2"></i>Madhukurisaibabu@gmail.com</p>
            </div>
        </div>
    </div>
    <div class="container-fluid py-4 px-sm-3 px-md-5">
        <p class="m-0 text-center">
            &copy; <a class="font-weight-semi-bold" href="#">Your Site Name</a>. All Rights Reserved. Designed by
            <a class="font-weight-semi-bold" href="https://htmlcodex.com">A7-Batch</a>
        </p>
    </div>
    <!-- Footer End -->


    <!-- Back to Top -->
    <a href="#" class="btn btn-lg btn-primary back-to-top"><i class="fa fa-angle-up"></i></a>


    <!-- JavaScript Libraries -->
    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.bundle.min.js"></script>
    <script src="lib/easing/easing.min.js"></script>
    <script src="lib/waypoints/waypoints.min.js"></script>
    <script src="lib/counterup/counterup.min.js"></script>
    <script src="lib/owlcarousel/owl.carousel.min.js"></script>

    <!-- Contact Javascript File -->
    <script src="mail/jqBootstrapValidation.min.js"></script>
    <script src="mail/contact.js"></script>

    <!-- Template Javascript -->
    <script src="js/main.js"></script>
</body>

</html>